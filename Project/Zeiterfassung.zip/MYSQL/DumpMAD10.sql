-- MySQL dump 10.13  Distrib 5.6.17, for Win64 (x86_64)
--
-- Host: MAD-W10    Database: ses
-- ------------------------------------------------------
-- Server version	5.6.23-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary table structure for view `v_zerf_erfassung`
--

DROP TABLE IF EXISTS `v_zerf_erfassung`;
/*!50001 DROP VIEW IF EXISTS `v_zerf_erfassung`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_zerf_erfassung` (
  `ZMIT_ID` tinyint NOT NULL,
  `ZMIT_Vorname` tinyint NOT NULL,
  `ZMIT_Zuname` tinyint NOT NULL,
  `ZMIT_Sortierung` tinyint NOT NULL,
  `ZTAE_Bezeichnung` tinyint NOT NULL,
  `ZTAE_Sortierung` tinyint NOT NULL,
  `ZERF_Von` tinyint NOT NULL,
  `ZERF_Bis` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `zerf_erfassung`
--

DROP TABLE IF EXISTS `zerf_erfassung`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zerf_erfassung` (
  `ZERF_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ZERF_ZMIT_ID` bigint(20) unsigned NOT NULL,
  `ZERF_ZTAE_ID` bigint(20) unsigned NOT NULL,
  `ZERF_Von` datetime NOT NULL,
  `ZERF_Bis` datetime DEFAULT NULL,
  PRIMARY KEY (`ZERF_ID`),
  UNIQUE KEY `UI_ZERF_ID` (`ZERF_ID`),
  KEY `FK_ZERF_ZMIT_idx` (`ZERF_ZMIT_ID`),
  KEY `FK_ZERF_ZTAE_idx` (`ZERF_ZTAE_ID`),
  CONSTRAINT `FK_ZERF_ZMIT` FOREIGN KEY (`ZERF_ZMIT_ID`) REFERENCES `zerf_mitarbeiter` (`ZMIT_ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_ZERF_ZTAE` FOREIGN KEY (`ZERF_ZTAE_ID`) REFERENCES `zerf_taetigkeiten` (`ZTAE_ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zerf_erfassung`
--

LOCK TABLES `zerf_erfassung` WRITE;
/*!40000 ALTER TABLE `zerf_erfassung` DISABLE KEYS */;
INSERT INTO `zerf_erfassung` VALUES (46,7,1,'2018-05-29 06:32:00','2018-05-29 15:08:50'),(56,7,2,'2018-05-11 08:54:59','2018-05-18 08:54:59'),(57,7,3,'2018-05-21 09:15:38','2018-05-25 10:15:00'),(58,7,1,'2018-05-02 05:29:00','2018-05-02 16:29:00'),(59,8,1,'2018-06-03 10:25:36','2018-06-03 10:25:41'),(60,8,1,'2018-06-03 12:24:59','2018-06-03 12:25:01'),(61,8,1,'2018-06-03 12:27:16','2018-06-03 12:27:17'),(62,8,1,'2018-06-03 12:27:18','2018-06-03 12:27:33'),(63,8,1,'2018-06-03 12:27:34','2018-06-03 12:27:34'),(64,10,1,'2018-06-03 12:27:35',NULL),(65,8,1,'2018-06-03 12:28:09','2018-06-03 12:28:23'),(66,8,1,'2018-06-03 12:28:47','2018-06-03 12:29:03'),(67,8,1,'2018-06-03 12:29:41','2018-06-03 12:30:03'),(68,8,1,'2018-06-03 12:30:15','2018-06-03 12:30:27'),(69,8,1,'2018-06-03 12:30:44','2018-06-03 12:30:58'),(70,8,1,'2018-06-03 12:31:18','2018-06-03 12:31:35'),(71,8,1,'2018-06-03 12:31:39',NULL),(72,7,1,'2018-06-05 15:12:24',NULL),(73,11,1,'2018-06-05 15:12:25',NULL),(74,8,1,'2018-06-07 14:37:03',NULL);
/*!40000 ALTER TABLE `zerf_erfassung` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zerf_feiertage`
--

DROP TABLE IF EXISTS `zerf_feiertage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zerf_feiertage` (
  `ZFEI_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ZFEI_Feiertag` date NOT NULL,
  `ZFEI_Beschreibung` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`ZFEI_ID`),
  UNIQUE KEY `UI_ZFEI_ID` (`ZFEI_ID`),
  UNIQUE KEY `UI_ZFEI_Feiertag` (`ZFEI_Feiertag`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zerf_feiertage`
--

LOCK TABLES `zerf_feiertage` WRITE;
/*!40000 ALTER TABLE `zerf_feiertage` DISABLE KEYS */;
INSERT INTO `zerf_feiertage` VALUES (1,'2018-05-01','1. Mai'),(9,'2018-05-10','Christi Himmelfahrt'),(10,'2018-05-20','Pfingstsonntag'),(11,'2018-05-21','Pfingsmontag'),(12,'2018-05-31','Fronleichnahm'),(13,'2018-08-15','Maria Himmelfahrt'),(14,'2018-10-26','Nationalfeiertag');
/*!40000 ALTER TABLE `zerf_feiertage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zerf_mitarbeiter`
--

DROP TABLE IF EXISTS `zerf_mitarbeiter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zerf_mitarbeiter` (
  `ZMIT_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ZMIT_Vorname` varchar(100) DEFAULT NULL,
  `ZMIT_Zuname` varchar(100) NOT NULL,
  `ZMIT_Geburtsdatum` date DEFAULT NULL,
  `ZMIT_Eintrittsdatum` date NOT NULL,
  `ZMIT_Wochenstunden` decimal(4,2) NOT NULL,
  `ZMIT_Aktiv` tinyint(1) NOT NULL DEFAULT '1',
  `ZMIT_Sortierung` int(10) unsigned NOT NULL,
  PRIMARY KEY (`ZMIT_ID`),
  UNIQUE KEY `UI_ZMIT_ID` (`ZMIT_ID`),
  UNIQUE KEY `UI_ZMIT_Sortierung` (`ZMIT_Sortierung`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zerf_mitarbeiter`
--

LOCK TABLES `zerf_mitarbeiter` WRITE;
/*!40000 ALTER TABLE `zerf_mitarbeiter` DISABLE KEYS */;
INSERT INTO `zerf_mitarbeiter` VALUES (7,'Andreas','Steinhauser',NULL,'2003-04-01',20.00,1,3),(8,'Thomas','Noll',NULL,'2018-01-02',38.50,1,2),(9,'Neuer','Mitarbeiter',NULL,'2018-05-29',38.50,1,6),(10,'fleißige','Biene',NULL,'2018-01-02',20.00,1,100),(11,'Max','Meier',NULL,'2018-01-01',38.50,1,101),(12,'Max','Huber',NULL,'2018-01-01',38.50,0,102),(13,'Karl ','Meier',NULL,'2018-01-01',38.50,0,104),(14,'einen','gibts noch',NULL,'2018-01-01',38.50,0,108),(15,'jetzt','will ich nicht mehr',NULL,'2018-01-01',38.50,0,120),(27,'undefined','dd',NULL,'2018-01-01',38.50,1,33),(28,'Andreas','',NULL,'2018-01-01',38.50,1,555);
/*!40000 ALTER TABLE `zerf_mitarbeiter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zerf_taetigkeiten`
--

DROP TABLE IF EXISTS `zerf_taetigkeiten`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zerf_taetigkeiten` (
  `ZTAE_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ZTAE_Bezeichnung` varchar(100) NOT NULL,
  `ZTAE_Pause` tinyint(1) NOT NULL DEFAULT '0',
  `ZTAE_GanzerTag` tinyint(1) NOT NULL DEFAULT '0',
  `ZTAE_Standard` tinyint(1) NOT NULL DEFAULT '0',
  `ZTAE_Sortierung` int(10) unsigned NOT NULL,
  PRIMARY KEY (`ZTAE_ID`),
  UNIQUE KEY `UI_ZTAE_Bezeichnung` (`ZTAE_Bezeichnung`),
  UNIQUE KEY `UI_ZTAE_ID` (`ZTAE_ID`),
  UNIQUE KEY `UI_ZTAE_Sortierung` (`ZTAE_Sortierung`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zerf_taetigkeiten`
--

LOCK TABLES `zerf_taetigkeiten` WRITE;
/*!40000 ALTER TABLE `zerf_taetigkeiten` DISABLE KEYS */;
INSERT INTO `zerf_taetigkeiten` VALUES (1,'Norm Arbeit',1,0,1,1),(2,'Urlaub',0,1,0,100),(3,'Krankenstand',0,1,0,50),(4,'Dienstreise',0,0,0,2);
/*!40000 ALTER TABLE `zerf_taetigkeiten` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'ses'
--

--
-- Dumping routines for database 'ses'
--

--
-- Final view structure for view `v_zerf_erfassung`
--

/*!50001 DROP TABLE IF EXISTS `v_zerf_erfassung`*/;
/*!50001 DROP VIEW IF EXISTS `v_zerf_erfassung`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_zerf_erfassung` AS select `zmit`.`ZMIT_ID` AS `ZMIT_ID`,`zmit`.`ZMIT_Vorname` AS `ZMIT_Vorname`,`zmit`.`ZMIT_Zuname` AS `ZMIT_Zuname`,`zmit`.`ZMIT_Sortierung` AS `ZMIT_Sortierung`,`ztae`.`ZTAE_Bezeichnung` AS `ZTAE_Bezeichnung`,`ztae`.`ZTAE_Sortierung` AS `ZTAE_Sortierung`,`zerf`.`ZERF_Von` AS `ZERF_Von`,`zerf`.`ZERF_Bis` AS `ZERF_Bis` from ((`zerf_erfassung` `zerf` join `zerf_mitarbeiter` `zmit` on(((`zerf`.`ZERF_ZMIT_ID` = `zmit`.`ZMIT_ID`) and (`zmit`.`ZMIT_Aktiv` = 1)))) join `zerf_taetigkeiten` `ztae` on((`zerf`.`ZERF_ZTAE_ID` = `ztae`.`ZTAE_ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-06-08 10:33:55
