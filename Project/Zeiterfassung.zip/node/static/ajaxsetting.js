$.ajaxSetup({
    method:'post',
});
$(document).ajaxError( function (e, jqxhr, settings, exception) {
    alert(settings.url + " Failed");
});

var language = "??";

var readLanguage = function(){
    $.ajax({
        url: "/optionen/get",
        method:'post',
        dataType:"json",
        success:function(result){
            language = result.language;
            DevExpress.localization.locale(result.language || 'de');
            setHeader();
            setTexte();
        }
    })
}

var setHeader = function(){
    let text = $('h1').html();
    let data = { language : language, text : text};
    $.ajax({
        url: "/zeiterfassung/gettext",
        dataType:"json",
        data: data,
        success:function(result){
            $('h1').html(result.text);
            $('title').html(result.text);
        }
    })
}

var translate = function(object){
    let text = $(object).html();
    let data = { language : language, text : text};
    $.ajax({
        url: "/zeiterfassung/gettext",
        dataType:"json",
        data: data,
        success:function(result){
            $(object).html(result.text);
        }
    })
}
