var uhr = function(){
    let art = "digital";
    $.ajax({
        url: "/optionen/get",
        method:'post',
        dataType:"json",
        success:function(result){
            art = result.uhransicht;
            if (art == "digital") {
                uhrdigital()
            }
            else {
                uhranalog()
            }
        }
    })
}

var uhrdigital = function(){
    var digi = 0;
    $('#uhr').width(360)
        .height(120);
    var canvas = $('#uhr').get(0);
    var ctx    = canvas.getContext('2d');

    $('#uhr').on('click', function(){
            document.location.href = "/"
    });
    $('#wer').on('click', function(){
            document.location.href = "/werwo"
    });


    uhrdigitalanimation(ctx)
    uhrdigitalanimation(ctx)
    setInterval(function(){
        uhrdigitalanimation(ctx)}
        , 1000);
}

var uhrdigitalanimation = function(ctx){
    ctx.clearRect(0, 0, 360, 120);
    let punkte = false;
    var now = new Date();
    var stunde = now.getHours();
    var minute = now.getMinutes();
    var sekunde= now.getSeconds();

    if (sekunde % 2 == 0) {
        punkte = true;
    }

    zeichne8(ctx, 0, Math.floor(stunde / 10), punkte);
    zeichne8(ctx, 20, stunde - (Math.floor(stunde / 10) * 10), punkte);

    zeichne8(ctx, 45, Math.floor(minute / 10), punkte);
    zeichne8(ctx, 65, minute - (Math.floor(minute / 10) * 10), punkte);

    zeichne8(ctx, 90, Math.floor(sekunde / 10), punkte);
    zeichne8(ctx, 110, sekunde - (Math.floor(sekunde / 10) * 10), punkte);
}

var zeichne8 = function(ctx, offset, digi, punkte){

    ctx.strokeStyle = '#3debd3';
    ctx.fillStyle = "#3debd3";

    if(punkte){
        ctx.beginPath();
        ctx.rect(42, 30, 3, 8);
        ctx.fill();

        ctx.beginPath();
        ctx.rect(42, 50, 3, 8);
        ctx.fill();

        ctx.beginPath();
        ctx.rect(87, 30, 3, 8);
        ctx.fill();

        ctx.beginPath();
        ctx.rect(87, 50, 3, 8);
        ctx.fill();
    }

    switch (digi){
        case 0: case 4: case 5: case 6: case 8: case 9:
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(offset + 5,5);
            ctx.lineTo(offset + 5,40);
            ctx.stroke();
            break;
    }

    switch (digi){
        case 0: case 2: case 3: case 5: case 6: case 7: case 8: case 9:
            ctx.lineWidth = 4;
            ctx.beginPath();
            ctx.moveTo(offset + 7,5);
            ctx.lineTo(offset + 15,5);
            ctx.stroke();
            break;
    }

    switch (digi){
        case 0: case 1: case 2: case 3: case 4: case 7: case 8: case 9:
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(offset + 17,5);
            ctx.lineTo(offset + 17,40);
            ctx.stroke();
            break;
    }

    switch (digi){
        case 0: case 1: case 3: case 4: case 5: case 6: case 7: case 8: case 9:
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(offset + 17,45);
            ctx.lineTo(offset + 17,80);
            ctx.stroke();
            break;
    }

    switch (digi){
        case 0: case 2: case 3: case 5: case 6: case 8: case 9:
            ctx.lineWidth = 4;
            ctx.beginPath();
            ctx.moveTo(offset + 7,80);
            ctx.lineTo(offset + 15,80);
            ctx.stroke();
            break;
    }

    switch (digi){
        case 0: case 2: case 6: case 8:
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(offset + 5,45);
            ctx.lineTo(offset + 5,80);
            ctx.stroke();
            break;
    }

    switch (digi){
        case 2: case 3: case 4: case 5: case 6: case 8: case 9:
            ctx.lineWidth = 4;
            ctx.beginPath();
            ctx.moveTo(offset + 7,43);
            ctx.lineTo(offset + 15,43);
            ctx.stroke();
            break;
    }
}

var uhranalog = function(){

    var canvas = $('#uhr').get(0);
    var ctx    = canvas.getContext('2d');
    var radius = canvas.height / 2;
    $('#uhr').on('click', function(){
        document.location.href = "/"
    });
    $('#wer').on('click', function(){
            document.location.href = "/werwo"
    });
    ctx.translate(radius, radius);
    //ctx.clearRect(0, 0, 100, 100);
    radius = radius * 0.90
    //uhranimation(ctx, radius);
    uhranaloganimation(ctx, radius)
    uhranaloganimation(ctx, radius)
    setInterval(function(){
        uhranaloganimation(ctx, radius)}
        , 1000);

};
var uhranaloganimation = function(ctx, radius){
    //  rand
    var grad;
    ctx.beginPath();
    ctx.arc(0, 0, radius, 0, 2*Math.PI);
    ctx.fillStyle = '#465672';
    ctx.fill();
    grad = ctx.createRadialGradient(0,0,radius*0.95, 0,0,radius*1.05);
    grad.addColorStop(0, '#3debd3');
    grad.addColorStop(1, '#465672');
    ctx.strokeStyle = grad;
    ctx.lineWidth = radius*0.1;
    ctx.stroke();
    // Stunden
    // 12 Uhr
    ctx.beginPath();
    ctx.moveTo(0 ,-60);
    ctx.lineTo(0 , -80);
    ctx.stroke();
    // 3 Uhr
    ctx.beginPath();
    ctx.moveTo(60 ,0);
    ctx.lineTo(80 ,0);
    ctx.stroke();
    // 6 Uhr
    ctx.beginPath();
    ctx.moveTo(0 ,60);
    ctx.lineTo(0, 80);
    ctx.stroke();
    // 9 Uhr
    ctx.beginPath();
    ctx.moveTo(-60 , 0);
    ctx.lineTo(-80 , 0);
    ctx.stroke();

    ctx.beginPath()
    ctx.moveTo(0, 0);
    ctx.lineTo(-80 , 0);

    var now = new Date();
    var stunde = now.getHours();
    var minute = now.getMinutes();
    var sekunde= now.getSeconds();

    stunde=stunde%12;
    stunde=(stunde*Math.PI/6)+(minute*Math.PI/(6*60));
    zeigeZeiger(ctx, stunde, radius*0.5, radius*0.07);

    minute=(minute*Math.PI/30);
    zeigeZeiger(ctx, minute, radius*0.8, radius*0.07);

    sekunde=(sekunde*Math.PI/30);
    zeigeZeiger(ctx, sekunde, radius*0.9, radius*0.02);
}

function zeigeZeiger(ctx, pos, length, width) {
    ctx.beginPath();
    ctx.lineWidth = width;
    ctx.lineCap = "round";
    ctx.moveTo(0,0);
    ctx.rotate(pos);
    ctx.lineTo(0, -length);
    ctx.stroke();
    ctx.rotate(-pos);
};
