var fs = require ('fs');
var express = require ('express');
var bp  = require ('body-parser');
var mysql = require('mysql');

var standardTaetigkeit = 0;

var optionen = {
    uhransicht : "analog",
    delay      : 3,
    editmode   : "form",
    language   : "de"
}
var mitarbeitercomment = [];

var texte = [
    { de:"Optionen", en:"options"},
    { de:"Auswertung", en:"evaluation"},
    { de:"Mitarbeiter", en:"employees"},
    { de:"Stammdaten", en:"masterdata"},
    { de:"Tätigkeiten", en:"activities"},
    { de:"wer wo", en:"who where"},
    { de:"Feiertage", en:"holidays"},
    { de:"kommen/gehen", en:"come on go"},
    { de:"ändern/ergänzen", en:"change/supplement"},
    { de:"Zeiterfassung", en:"time recording"},
    { de:"", en:""},
]


const OK = {
    OK:"OK"
}

const hostname = 'localhost';
const OPTIONENFILENAME = "ZeiterfassungOptionen.json"

//const hostname = 'dell-ses';
const port = 3001;

const con = mysql.createConnection({
    host: hostname,
    user: "ses",
    password: "WIFI",
    timezone: 'utc',
    connect_timeout: 28800
});

fs.exists(OPTIONENFILENAME, function(exists){
    if (!exists){
        console.log("neuanlage von Optionen");
        fs.writeFile(OPTIONENFILENAME, JSON.stringify(optionen), function(err){
            if(err){
                console.log("Error Create File " + OPTIONENFILENAME + ":" + err);
            }
            else {
                readOptionenfromFile();
            }
        });
    }
    else{
        readOptionenfromFile();
    }
});

var app = express();

var server = app.listen(port, function(){
    console.log("server-zeit.js hört an Port : " + port);
})

app.use(express.static('static'));
app.use(bp.urlencoded({extended:true}));
app.use(bp.json({}));

///////////////////////////////////////////  HTML /////////////////////////////////////////
app.get( '/', function(req, res){
    res.sendFile(__dirname+'/static/zeiterfassung.html');
});

app.get( '/kommengehen', function(req, res){
    res.sendFile(__dirname+'/static/kommengehen.html');
});

app.get( '/aendern', function(req, res){
    res.sendFile(__dirname+'/static/aendern.html');
});

app.get( '/auswertung', function(req, res){
    res.sendFile(__dirname+'/static/auswertung.html');
});

app.get( '/stammdaten', function(req, res){
    res.sendFile(__dirname+'/static/stammdaten.html');
});

app.get( '/stammdaten/mitarbeiter', function(req, res){
    res.sendFile(__dirname+'/static/mitarbeiter.html');
});

app.get( '/stammdaten/taetigkeiten', function(req, res){
    res.sendFile(__dirname+'/static/taetigkeiten.html');
});

app.get( '/stammdaten/feiertage', function(req, res){
    res.sendFile(__dirname+'/static/feiertage.html');
});

app.get( '/stammdaten/options', function(req, res){
    res.sendFile(__dirname+'/static/options.html');
});

app.get( '/werwo', function(req, res){
    res.sendFile(__dirname+'/static/werwo.html');
});


///////////////////////////////////////////  Daten / Mitarbeiter lesen/////////////////////////////////////////
app.post( '/mitarbeiter/getall', function(req, res){
    con.query("select * from ses.ZERF_Mitarbeiter order by ZMIT_Sortierung", function (err, result) {
        if (err) {
            returnError(res, 500, err);
        }
        else {
            for (let i in result){
                result[i].ZMIT_Aktiv = (result[i].ZMIT_Aktiv == 1) ? true : false;
            }
            res.setHeader('content-type', 'application/json')
            res.writeHeader (200);
            res.end(JSON.stringify(result));
        };
    });
});

///////////////////////////////////////////  Daten / Mitarbeiter update /////////////////////////////////////////
app.post( '/mitarbeiter/update', function(req, res){
    let eintrittsdatum = req.body.values.ZMIT_Eintrittsdatum;
    eintrittsdatum = eintrittsdatum.substring(0, 10);
    req.body.values.ZMIT_Aktiv = (req.body.ZMIT_Aktiv == 'true') ? 1 : 0;
    let sql = "update ses.ZERF_Mitarbeiter set"
    sql+= " ZMIT_Vorname = '" + req.body.values.ZMIT_Vorname + "',";
    sql+= " ZMIT_Zuname = '" + req.body.values.ZMIT_Zuname + "',";
    sql+= " ZMIT_Eintrittsdatum = '" + eintrittsdatum + "',";
    sql+= " ZMIT_Wochenstunden = " + req.body.values.ZMIT_Wochenstunden + ",";
    sql+= " ZMIT_Aktiv = " + req.body.values.ZMIT_Aktiv + ",";
    sql+= " ZMIT_Sortierung = " + req.body.values.ZMIT_Sortierung;
    sql+= " where ZMIT_ID = " + req.body.values.ZMIT_ID;

    con.query(sql, function (err, result) {
        if (err) {
            returnError(res, 500, err);
        }
        else {
            returnOK(res);
        };
    });
});

///////////////////////////////////////////  Daten / Mitarbeiter Insert /////////////////////////////////////////
//app.post( '/mitarbeiter/insert', function(req, res){
app.post( '/mitarbeiter/insert', function(req, res){
    let eintrittsdatum = req.body.values.ZMIT_Eintrittsdatum;
    eintrittsdatum = eintrittsdatum.substring(0, 10);

    req.body.values.ZMIT_Aktiv = (req.body.values.ZMIT_Aktiv == 'true') ? 1 : 0;

    let sql = "insert into ses.ZERF_Mitarbeiter "
    sql+= "(ZMIT_Vorname, ZMIT_Zuname, ZMIT_Eintrittsdatum, ZMIT_Wochenstunden, ZMIT_Aktiv, ZMIT_Sortierung) "
    sql+= " Values "
    sql+= "('" + req.body.values.ZMIT_Vorname + "', '" + req.body.values.ZMIT_Zuname + "', '" + eintrittsdatum + "', " + req.body.values.ZMIT_Wochenstunden + "," + req.body.values.ZMIT_Aktiv + "," + req.body.values.ZMIT_Sortierung + ")";

    con.query(sql, function (err, result) {
        if (err) {
            returnError(res, 500, err);
        }
        else {
            returnOK(res);
        };
    });
});
///////////////////////////////////////////  Daten / Mitarbeiter Delete /////////////////////////////////////////
app.post( '/mitarbeiter/remove', function(req, res){
    let sql = "delete from ses.ZERF_Mitarbeiter where ZMIT_ID = " + req.body.values.ZMIT_ID;
    con.query(sql, function (err, result) {
        if (err) {
            returnError(500, err);
        }
        else {
            returnOK(res);
        }
    });
});

///////////////////////////////////////////  Daten / Tätigkeiten lesen/////////////////////////////////////////
app.post( '/taetigkeiten/getall', function(req, res){
    con.query("select * from ses.ZERF_Taetigkeiten order by ZTAE_Sortierung", function (err, result) {
        if (err) {
            returnError(res, 500, err);
        }
        else {
            for (let i in result){
                result[i].ZTAE_Pause = (result[i].ZTAE_Pause == 1) ? true : false;
                result[i].ZTAE_GanzerTag = (result[i].ZTAE_GanzerTag == 1) ? true : false;
                result[i].ZTAE_Standard = (result[i].ZTAE_Standard == 1) ? true : false;
            }
            res.setHeader('content-type', 'application/json')
            res.writeHeader (200);
            res.end(JSON.stringify(result));
        }
    });
});

///////////////////////////////////////////  Daten / Tätigkeiten update /////////////////////////////////////////
app.post( '/taetigkeiten/update', function(req, res){
    req.body.values.ZTAE_Pause     = (req.body.values.ZTAE_Pause     == 'true') ? 1 : 0;
    req.body.values.ZTAE_GanzerTag = (req.body.values.ZTAE_GanzerTag == 'true') ? 1 : 0;
    req.body.values.ZTAE_Standard  = (req.body.values.ZTAE_Standard  == 'true') ? 1 : 0;
    let sql = "update ses.ZERF_Taetigkeiten set"
    sql+= " ZTAE_Bezeichnung = '" + req.body.values.ZTAE_Bezeichnung + "',";
    sql+= " ZTAE_Pause = '" + req.body.values. ZTAE_Pause + "',";
    sql+= " ZTAE_GanzerTag = " + req.body.values.ZTAE_GanzerTag + ", ";
    sql+= " ZTAE_Sortierung = " + req.body.values.ZTAE_Sortierung + ", ";
    sql+= " ZTAE_Standard = " + req.body.values.ZTAE_Standard;
    sql+= " where ZTAE_ID = " + req.body.values.ZTAE_ID;

    con.query(sql, function (err, result) {
        if (err) {
            returnError(res, 500, err);
        }
        else {
            returnOK(res);
        }
    });
});
///////////////////////////////////////////  Daten / Tätigkeiten Insert /////////////////////////////////////////
app.post( '/taetigkeiten/insert', function(req, res){
    req.body.values.ZTAE_Pause     = (req.body.values.ZTAE_Pause     == 'true') ? 1 : 0;
    req.body.values.ZTAE_GanzerTag = (req.body.values.ZTAE_GanzerTag == 'true') ? 1 : 0;
    req.body.values.ZTAE_Standard  = (req.body.values.ZTAE_Standard  == 'true') ? 1 : 0;
    let sql = "insert into ses.ZERF_Taetigkeiten "
    sql+= "(ZTAE_Bezeichnung, ZTAE_Pause, ZTAE_GanzerTag, ZTAE_Sortierung, ZTAE_Standard) "
    sql+= " Values "
    sql+= "('" + req.body.values.ZTAE_Bezeichnung + "', " + req.body.values.ZTAE_Pause + ", " + req.body.values.ZTAE_GanzerTag + ", " + req.body.values.ZTAE_Sortierung + ", " + req.body.values.ZTAE_Standard + ")";


    con.query(sql, function (err, result) {
        if (err) {
            returnError(res, 500, err);
        }
        else {
            returnOK(res);
        }
    });
});
///////////////////////////////////////////  Daten / Tätigkeiten Delete /////////////////////////////////////////
app.post( '/taetigkeiten/remove', function(req, res){
    let sql = "delete from ses.ZERF_Taetigkeiten where ZTAE_ID = " + req.body.values.ZTAE_ID;
    con.query(sql, function (err, result) {
        if (err) {
            returnError(res, 500, err);
        }
        else {
            returnOK(res);
        }
    });
});

///////////////////////////////////////////  Daten / Feiertage alle lesen /////////////////////////////////////////
app.post( '/feiertage/getall', function(req, res){
    con.query("select * from ses.ZERF_Feiertage", function (err, result) {
        if (err) {
            returnError(res, 500, err);
        }
        else {
            res.setHeader('content-type', 'application/json')
            res.writeHeader (200);
            res.end(JSON.stringify(result));
        }
    });
});

///////////////////////////////////////////  Daten / Feiertage update /////////////////////////////////////////
app.post( '/feiertage/update', function(req, res){
    let feiertag = req.body.values.ZFEI_Feiertag;
    feiertag = feiertag.substring(0, 10);
    let sql = "update ses.ZERF_Feiertage set"
    sql+= " ZFEI_Beschreibung = '" + req.body.values.ZFEI_Beschreibung + "',";
    sql+= " ZFEI_Feiertag = '" + feiertag + "'";
    sql+= " where ZFEI_ID = " + req.body.values.ZFEI_ID;

    con.query(sql, function (err, result) {
        if (err) {
            returnError(res, 500, err);
        }
        else {
            returnOK(res);
        }
    });
});

///////////////////////////////////////////  Daten / Feiertage Insert /////////////////////////////////////////
app.post( '/feiertage/insert', function(req, res){
    let feiertag = req.body.values.ZFEI_Feiertag;
    feiertag = feiertag.substring(0, 10);
    let sql = "insert into ses.ZERF_Feiertage "
    sql+= "(ZFEI_Beschreibung, ZFEI_Feiertag) "
    sql+= " Values "
    sql+= "('" + req.body.values.ZFEI_Beschreibung + "', '" + feiertag + "')";

    con.query(sql, function (err, result) {
        if (err) {
            returnError(res, 500, err);
        }
        else {
            returnOK(res);
        }
    });
});
///////////////////////////////////////////  Daten / Feiertage Delete /////////////////////////////////////////
app.post( '/feiertage/remove', function(req, res){
    let sql = "delete from ses.ZERF_Feiertage where ZFEI_ID = " + req.body.values.ZFEI_ID;
    con.query(sql, function (err, result) {
        if (err) {
            returnError(res, 500, err);
        }
        else {
            returnOK(res);
        }
    });
});

///////////////////////////////////////////  Daten / Zeiterfassung alle lesen /////////////////////////////////////////
app.post('/zeiterfassung/getall', function(req, res){
        let sql = "SELECT * from ses.ZERF_Erfassung";

        con.query(sql, function (err, result) {
            if (err) {
                returnError(res, 500, err);
            }
            else {
                sendData(result);
            }
        });

        var sendData = function(result){
            res.setHeader('content-type', 'application/json')
            res.writeHeader (200);
            res.end(JSON.stringify(result));
        }
});
///////////////////////////////////////////  Daten / Zeiterfassung update /////////////////////////////////////////
app.post( '/zeiterfassung/update', function(req, res){
    if (req.body.values.ZERF_Von == "") {
        req.body.values.ZERF_Von = "null"
    }
    else {
        req.body.values.ZERF_Von = "'" + req.body.values.ZERF_Von.slice(0, 19).replace('T', ' ') + "'";
    };

    if (req.body.values.ZERF_Bis == "") {
        req.body.values.ZERF_Bis = "null"
    }
    else {
        req.body.values.ZERF_Bis = "'" + req.body.values.ZERF_Bis.slice(0, 19).replace('T', ' ') + "'";
    };


    let sql = "update ses.ZERF_Erfassung set"
    sql+= " ZERF_ZMIT_ID = " + req.body.values.ZERF_ZMIT_ID + ",";
    sql+= " ZERF_ZTAE_ID = " + req.body.values.ZERF_ZTAE_ID + ",";
    sql+= " ZERF_Von     = " + req.body.values.ZERF_Von + ", ";
    sql+= " ZERF_Bis     = " + req.body.values.ZERF_Bis;
    sql+= " where ZERF_ID = " + req.body.values.ZERF_ID;

    con.query(sql, function (err, result) {
        if (err) {
            returnError(res, 500, err);
        }
        else {
            returnOK(res);
        }
    });
});
///////////////////////////////////////////  Daten / Zeiterfassung Insert /////////////////////////////////////////
app.post( '/zeiterfassung/insert', function(req, res){
    if (req.body.values.ZERF_Von == "") {
        req.body.values.ZERF_Von = "null"
    }
    else {
        req.body.values.ZERF_Von = "'" + req.body.values.ZERF_Von.slice(0, 19).replace('T', ' ') + "'";
    };

    if (req.body.values.ZERF_Bis == "") {
        req.body.values.ZERF_Bis = "null"
    }
    else {
        req.body.values.ZERF_Bis = "'" + req.body.values.ZERF_Bis.slice(0, 19).replace('T', ' ') + "'";
    };

    let sql = "insert into ses.ZERF_Erfassung "
    sql+= "(ZERF_ZMIT_ID, ZERF_ZTAE_ID, ZERF_Von, ZERF_Bis) "
    sql+= " Values "
    sql+= "(" + req.body.values.ZERF_ZMIT_ID + "," + req.body.values.ZERF_ZTAE_ID + ", " + req.body.values.ZERF_Von + ", " + req.body.values.ZERF_Bis + ")";


    con.query(sql, function (err, result) {
        if (err) {
            returnError(res, 500, err);
        }
        else {
            returnOK(res);
        }
    });
});

///////////////////////////////////////////  Daten / Feiertage Delete /////////////////////////////////////////
app.post( '/zeiterfassung/remove', function(req, res){
    let sql = "delete from ses.ZERF_Erfassung where ZERF_ID = " + req.body.values.ZERF_ID;
    con.query(sql, function (err, result) {
        if (err) {
            returnError(res, 500, err);
        }
        else {
            returnOK(res);
        }
    });
});
/////////////////////////////////////////// Übersetzung ////////////////////////////////////////////////////////
/////////////////////////////////////////text übersetzen////////////////////////////////////////////////////////
app.post('/zeiterfassung/gettext', function(req, res){
    let text = {text : req.body.text};
    for (i=0;i<texte.length;i++){
        if (req.body.text == texte[i].de){
            switch (req.body.language) {
                case "de":
                    text.text = texte[i].de;
                    break;
                case "en":
                    text.text = texte[i].en;
                    break;
            }
        }
    }

    res.setHeader('content-type', 'application/json')
    res.writeHeader (200);
    res.end(JSON.stringify(text));
});


/////////////////////////////////////////// Optionen ///////////////////////////////////////////////////////////
/////////////////////////////////////////////lesen//////////////////////////////////////////////////////////////
app.post('/optionen/get', function(req, res){
    res.setHeader('content-type', 'application/json')
    res.writeHeader (200);
    res.end(JSON.stringify(optionen));
});

/////////////////////////////////////////////schreiben//////////////////////////////////////////////////////////////
app.post('/optionen/set', function(req, res){
    switch (req.body.optionen.uhransicht){
        case "digital": case "analog":
            optionen.uhransicht = req.body.optionen.uhransicht;
            break;
    }
    if (req.body.optionen.delay >= 1 && req.body.optionen.delay <= 10){
        optionen.delay = req.body.optionen.delay;
    }

    switch (req.body.optionen.editmode){
        case "row": case "form": case "cell":
            optionen.editmode = req.body.optionen.editmode;
    }

    switch (req.body.optionen.language){
        case "de": case "en":
            optionen.language = req.body.optionen.language;
    }


    if (writeOptionentoFile() < 0){
        returnError(res)
    }
    else {
        returnOK(res);
    };
});
/////////////////////////////////////////////comment lesen//////////////////////////////////////////////////////////////
app.post('/zeiterfassung/getcomment', function(req, res){
    let aktZeit = req.body.aktZeit;
    let anzahlMitarbeiter = 0;
    let sql = "SELECT ZMIT_ID, ZMIT_Vorname, ZMIT_Zuname, ZMIT_Sortierung ";
    sql+= " FROM ses.ZERF_Mitarbeiter ";
    sql+= " WHERE   ZMIT_Aktiv = 1";
    sql+= " ORDER BY ZMIT_Sortierung";

    con.query(sql, function (err, mitresult) {
        if (err) {
            returnError(res, 500, err);
        }
        else {
            getZeitEntraege(mitresult);
        }
    });

    var getZeitEntraege = function(mitresult){
        if (mitresult.length == 0){
            res.setHeader('content-type', 'application/json')
            res.writeHeader (200);
            res.end(JSON.stringify(mitresult));
            return;
        }
        anzahlMitarbeiter = 0;

        for (let i=0;i<mitresult.length;i++){
            let sql = "SELECT * from ses.ZERF_Erfassung "
            sql+= " where ZERF_ZMIT_ID = " + mitresult[i].ZMIT_ID;
            sql+= " and DATE(ZERF_Von) = '" + aktZeit + "'";
            sql+= " order by ZERF_ID desc";

            con.query(sql, function (err, erfresult) {
                if (err) {
                    returnError(res, 500, err);
                }
                else {
                    if (erfresult.length < 1){
                        mitresult[i].status = "außer Haus"
                    }
                    else {
                        if(erfresult[0].ZERF_Bis == null){
                            mitresult[i].status = "- Anwesend";
                        }
                        else {
                            mitresult[i].status = "außer Haus";
                        }
                    }
                    mitresult[i].comment = mitarbeitercomment[mitresult[i].ZMIT_ID];
                    sendData(mitresult);
                }
            });
        }
    }

    var sendData = function(mitresult){
        anzahlMitarbeiter++;
        if (anzahlMitarbeiter == mitresult.length){
            res.setHeader('content-type', 'application/json')
            res.writeHeader (200);
            res.end(JSON.stringify(mitresult));
        }
    }
});
/////////////////////////////////////////////comment lesen//////////////////////////////////////////////////////////////
app.post('/zeiterfassung/setcomment', function(req, res){
    mitarbeitercomment[req.body.values.ZMIT_ID] = req.body.values.comment;
    returnOK(res);
});


/////////////////////////////////////////// für kommen/gehen ///////////////////////////////////////////////////
///////////////////////////////////Abfrage Mitarbeiter an/abwesen///////////////////////////////////////////////
app.post('/zeiterfassung/anwesend', function(req, res){
    let aktZeit = req.body.aktZeit;
    let anzahlMitarbeiter = 0;
    let sql = "SELECT ZMIT_ID, ZMIT_Vorname, ZMIT_Zuname, ZMIT_Sortierung ";
    sql+= " FROM ses.ZERF_Mitarbeiter ";
    sql+= " WHERE   ZMIT_Aktiv = 1";
    sql+= " ORDER BY ZMIT_Sortierung";

    con.query(sql, function (err, mitresult) {
        if (err) {
            returnError(res, 500, err);
        }
        else {
            getZeitEntraege(mitresult);
        }
    });

    var getZeitEntraege = function(mitresult){
        if (mitresult.length == 0){
            res.setHeader('content-type', 'application/json')
            res.writeHeader (200);
            res.end(JSON.stringify(mitresult));
            return;
        }
        anzahlMitarbeiter = 0;

        for (let i=0;i<mitresult.length;i++){
            let sql = "SELECT * from ses.ZERF_Erfassung "
            sql+= " where ZERF_ZMIT_ID = " + mitresult[i].ZMIT_ID;
            sql+= " and DATE(ZERF_Von) = '" + aktZeit + "'";
            sql+= " order by ZERF_ID desc";
            con.query(sql, function (err, erfresult) {
                if (err) {
                    returnError(res, 500, err);
                }
                else {
                    if (erfresult.length < 1){
                        mitresult[i].anwesend = "N";
                    }
                    else {
                        if(erfresult[0].ZERF_Bis == null){
                            mitresult[i].anwesend = "J";
                        }
                        else {
                            mitresult[i].anwesend = "N";
                        }
                    }
                    sendData(mitresult);
                }
            });
        }
    }

    var sendData = function(mitresult){
        anzahlMitarbeiter++;
        if (anzahlMitarbeiter == mitresult.length){
            res.setHeader('content-type', 'application/json')
            res.writeHeader (200);
            res.end(JSON.stringify(mitresult));
        }

        let sql = "SELECT ZTAE_ID from ses.ZERF_Taetigkeiten where ZTAE_Standard = 1 order by ZTAE_ID"
        con.query(sql, function (err, tatresult) {
            if (err) {
                returnError(res, 500, err);
            }
            else {
                if (tatresult.length > 0){
                    standardTaetigkeit = tatresult[0].ZTAE_ID;
                }
            }
        });
    }
});
///////////////////////////////////Mitarbeiter kommen/gehen setzen///////////////////////////////////
app.post('/zeiterfassung/kommengehen', function(req, res){
        var istda = req.body.anwesend;
        var mitID = req.body.mitarbeiterID;
        var aktZeit = req.body.aktZeit;
        let sql = "SELECT * from ses.ZERF_Erfassung where ZERF_ZMIT_ID = " + req.body.mitarbeiterID;
        sql+= " and DATE(ZERF_Von) = '" + aktZeit.substr(0, 10) + "'";
        sql+= " order by ZERF_ID desc";

        con.query(sql, function (err, result) {
            if (err) {
                returnError(res, 500, err);
            }
            else {
                searchaktuellenEintrag(result);
            }
        });

        var searchaktuellenEintrag = function(result){

            if (result.length == 0){
                macheneuenEintrag();
            }
            else {
                if (result[0].ZERF_Bis == null){
                    abschlussEintrag(result);
                }
                else {
                    macheneuenEintrag();
                }
            }
        }

        var macheneuenEintrag = function(){
            let sql = "INSERT into ses.ZERF_Erfassung ";
            sql+= " (ZERF_ZMIT_ID, ZERF_ZTAE_ID, ZERF_Von)";
            sql+= " Values ";
            sql+= " (" + mitID + ", " + "1" + ", '" + aktZeit + "')";

            con.query(sql, function (err, result) {
                if (err) {
                    returnError(res, 500, err);
                }
                else {
                    returnOK(res);
                }
            });
        }

        var abschlussEintrag = function(result){
            let sql = "UPDATE ses.ZERF_Erfassung ";
            sql+= " set ZERF_Bis = '" + aktZeit + "'";
            sql+= " where ZERF_ID = " + result[0].ZERF_ID;

            con.query(sql, function (err, result) {
                if (err) {
                    returnError(res, 500, err);
                }
                else {
                    returnOK(res)
                }
            });
        }
});

///////////////////////////////////Mitarbeiter datum_von, datum_bis berechnete Zeit///////////////////////////////////
app.post('/zeiterfassung/getlist', function(req, res){
    var resultSet = [];
    var resultObject = {};
    var feiertage;
    var zeiten;
    var taetigkteien;
    var wochenminuten = [];
    var wochenstunden;
    let mitID = req.body.mitarbeiter.ZMIT_ID || 0;
    let sql = "SELECT * from ses.ZERF_Erfassung where ZERF_ZMIT_ID = " + mitID;
    sql+= " and DATE(ZERF_Von) between '" + req.body.datum_von + "' and '" + req.body.datum_bis + "'";
    sql+= " order by ZERF_Von asc";

    con.query(sql, function (err, result) {
        if (err) {
            returnError(res, 500, err);
        }

         else {
             zeiten = result;
             readMitarbeiterZeit(mitID)
        }
    });

    var readMitarbeiterZeit = function(mitID) {
        let sql = "SELECT ZMIT_Wochenstunden from ses.ZERF_Mitarbeiter where ZMIT_ID = " + mitID;

        con.query(sql, function (err, result) {
            if (err) {
                returnError(res, 500, err);
            }

             else {
                 wochenstunden = result;
                 if (wochenstunden.length > 0){
                     switch (wochenstunden[0].ZMIT_Wochenstunden){
                         case 0:
                            wochenminuten = [0, 0, 0, 0, 0, 0, 0]
                            break;
                        case 20:
                            wochenminuten = [240, 240, 240, 240, 240, 0, 0]
                            break;
                        case 38.5:
                            wochenminuten = [480, 480, 480, 480, 390, 0, 0]
                            break;
                    }
                }
                else {
                    wochenminuten = [0, 0, 0, 0, 0, 0, 0]
                }
                 readTaetigkeiten()
            }
        });
    }

    var readTaetigkeiten = function() {
        let sql = "SELECT * from ses.ZERF_Taetigkeiten order by ZTAE_Sortierung";

        con.query(sql, function (err, result) {
            if (err) {
                returnError(res, 500, err);
            }

             else {
                 taetigkeiten = result;
                 readFeiertage()
            }
        });
    }



    var readFeiertage = function() {
        let sql = "SELECT ZFEI_Feiertag from ses.ZERF_Feiertage ";
        sql+= " where DATE(ZFEI_Feiertag) between '" + req.body.datum_von + "' and '" + req.body.datum_bis + "'";
        sql+= " order by ZFEI_Feiertag asc";

        con.query(sql, function (err, result) {
            if (err) {
                returnError(res, 500, err);
            }

             else {
                 feiertage = result;
                 berechneZeiten()
            }
        });
    }

    var berechneZeiten = function(){
        let datum_von = new Date(req.body.datum_von)
        let datum_bis = new Date(req.body.datum_bis)
        let milli = datum_bis - datum_von;
        const ONEDAY = 1 * 24 * 60 * 60 * 1000;
        let sec = milli / 1000;
        let min = sec / 60;
        let stu = min / 60
        let day = stu / 24;
        day = Math.floor(day) +1;

        //Tage aufbauen
        for (let i=0; i < day; i++){
            let wotag = "";
            let soll = 0;
            let ist  = 0;
            let canwork = true;
            let bemerkung = '';
            let resultDate = new Date(datum_von + " GMT+00:00");
            resultDate.setDate(resultDate.getDate() + (1 * i));
            let inttag =  resultDate.getDay();
            switch (inttag){
                case 0:
                    wotag = "So";
                    soll = wochenminuten[6];
                    break;
                case 1:
                    wotag = "Mo";
                    soll = wochenminuten[0];
                    break;
                case 2:
                    wotag = "Di";
                    soll = wochenminuten[1];
                    break;
                case 3:
                    wotag = "Mi";
                    soll = wochenminuten[2];
                break;
                case 4:
                    wotag = "Do";
                    soll = wochenminuten[3];
                break;
                case 5:
                    wotag = "Fr";
                    soll = wochenminuten[4];
                break;
                case 6:
                    wotag = "Sa";
                    soll = 0;
                    soll = wochenminuten[5];
                break;
            }

            // Feiertage ermitteln
            for (let j=0;j< feiertage.length;j++){
                if (feiertage[j].ZFEI_Feiertag.toISOString().slice(0, 10) ==  resultDate.toISOString().slice(0, 10)) {
                    soll = 0;
                    bemerkung = "Feiertag";
                }
            }

            // urlaub krankenstand aufbereiten
            for (let j=0;j< taetigkeiten.length;j++){
                if (taetigkeiten[j].ZTAE_GanzerTag == 1){
                    for (let k=0;k < zeiten.length;k++){
                        if (zeiten[k].ZERF_ZTAE_ID == taetigkeiten[j].ZTAE_ID){
                            if (resultDate.toISOString().slice(0, 10) >= zeiten[k].ZERF_Von.toISOString().slice(0, 10) && resultDate.toISOString().slice(0, 10) <= zeiten[k].ZERF_Bis.toISOString().slice(0, 10)){
                                if (bemerkung == "" && soll > 0){
                                    bemerkung = taetigkeiten[j].ZTAE_Bezeichnung;
                                    ist = soll;
                                }
                            }
                        }
                    }
                }
            }

            // normale Arbeitszeit aufbereiten
            for (let j=0;j< taetigkeiten.length;j++){
                if (taetigkeiten[j].ZTAE_GanzerTag == 0){
                    for (let k=0;k < zeiten.length;k++){
                        if (zeiten[k].ZERF_ZTAE_ID == taetigkeiten[j].ZTAE_ID){
                            if (resultDate.toISOString().slice(0, 10) == zeiten[k].ZERF_Von.toISOString().slice(0, 10) && resultDate.toISOString().slice(0, 10) == zeiten[k].ZERF_Bis.toISOString().slice(0, 10)){
                                if (soll > 0){
                                    let zeit = zeiten[k].ZERF_Bis - zeiten[k].ZERF_Von;
                                    zeit = zeit / 1000 / 60; // rechnen auf minuten
                                    if (zeit > 360) {
                                        if (zeit > 390) {
                                            zeit = zeit - 30;
                                        }
                                        else {
                                            zeit = 360;
                                        }
                                    }
                                    zeit = Math.round(zeit, 0);
                                    ist+=zeit;
                                }
                            }
                        }
                    }
                }
            }

            let resultLine = {
                    datum : resultDate,
                    tag : wotag,
                    soll : soll,
                    bemerkung : bemerkung,
                    ist : ist,
                    diff : ist - soll
            };

            resultSet.push(resultLine);
        }

        returnResult();
    }
    var returnResult = function(){
        res.setHeader('content-type', 'application/json')
        res.writeHeader (200);
        res.end(JSON.stringify(resultSet));
    }
});


var returnError = function(res, code, err){
    console.log(err);
    res.setHeader('content-type', 'application/json')
    res.writeHeader (code);
    res.end(JSON.stringify(err));
};

var returnOK = function(res){
    res.setHeader('content-type', 'application/json');
    res.writeHeader (200);
    res.end(JSON.stringify(OK));
};

var connect = function(){
    con.connect(function(err){
        if(err) { throw err }
         // con.query("select * from ses.ZERF_Erfassung", function (err, result) {
         //  if(err) throw err;
         //  console.log(result);
         //  })
    })
    // con.query("update ses.ZERF_Mitarbeiter set ZMIT_Eintrittsdatum = '2018-01-01'", function (err, result) {
    //     if(err) throw err;
    // })
}

connect();

var readOptionenfromFile = function(){
    fs.readFile(OPTIONENFILENAME, function(err, data){
        if (err){
            console.log("Error Read File " + OPTIONENFILENAME + ":" + err);
        }
        else {
            optionen = JSON.parse(data);
            }
    });
};
var writeOptionentoFile = function(){
    fs.writeFile(OPTIONENFILENAME, JSON.stringify(optionen), function(err){
      if(err){
          console.log("Error write file " + OPTIONENFILENAME + ":" + err);
        return -1;
      }
  })
}
